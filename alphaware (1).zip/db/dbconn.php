<?php
	$conn=mysqli_connect("localhost","root","", "alphaware") or die(mysql_error());
?>
